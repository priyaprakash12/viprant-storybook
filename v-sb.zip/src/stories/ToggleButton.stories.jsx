import React from 'react';
import { ToggleButton } from './ToggleButton';

export default {
    title: 'Example/ToggleButton',
    component: ToggleButton,
    parameters: {
        layout: 'fullscreen',
    },
};

const Template = (args) => <ToggleButton {...args} />;

export const Toggle = Template.bind({});
Toggle.args = {
    primary: true,
    label: 'I accept',
};

// export const Reject = Template.bind({});
// Reject.args = {
//     primary: false,
//     label: 'I reject',
// };
