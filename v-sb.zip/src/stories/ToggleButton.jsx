import React, { useState } from "react";
import PropTypes from "prop-types";
import "./ToggleButton.css";

export const ToggleButton = ({
  primary,
  backgroundColor,
  size,
  label,
  accept,
  reject,
  ...props
}) => {
  const mode = primary ? "accept" : "reject";
  const [confirm, setConfirm] = useState(false);
  return (
    <footer>
      <div className="wrap">
        <div>
          <button
            onClick={() => {
              setConfirm(!confirm);
            }}
            type="button"
            className={["accept", "reject", mode].join(" ")}
            //style={backgroundColor }
            {...props}
          >
            {confirm ? "I accept " : "I reject"}
          </button>
        </div>
      </div>
    </footer>
  );
};
ToggleButton.propTypes = {
  primary: PropTypes.bool,
};
ToggleButton.defaultProps = {
  primary: true,
};
